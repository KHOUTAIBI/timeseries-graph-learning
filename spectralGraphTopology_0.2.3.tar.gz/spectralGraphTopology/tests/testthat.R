library(testthat)
library(spectralGraphTopology)

test_check("spectralGraphTopology")
