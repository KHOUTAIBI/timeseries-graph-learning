#include <RcppArmadillo.h>
#define NDEBUG 1
#include <RcppEigen.h>
